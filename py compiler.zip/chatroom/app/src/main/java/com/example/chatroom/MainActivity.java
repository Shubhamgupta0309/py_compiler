package com.example.chatroom;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends AppCompatActivity {

    TextView output;
    EditText codeArea;
    Button run;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        output = (TextView) findViewById(R.id.output);
        codeArea = (EditText) findViewById(R.id.codeArea);
        run = (Button) findViewById(R.id.run);



        if (! Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        run.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Python py = Python.getInstance();

                PyObject pyObj = py.getModule("myScript");


                PyObject obj = pyObj.callAttr("main",codeArea.getText().toString());


                output.setText(obj.toString());
            }
        });


    }
}